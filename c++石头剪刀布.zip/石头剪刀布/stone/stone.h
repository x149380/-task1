#pragma once
#include<iostream>
#include<stdlib.h>
#include<ctime>
using namespace std;
class stone
{
public:
	stone(void);
	~stone(void);
	void put();
	void jieguo(float&,float&,float&,float&);
	void zhanji(float&,float&,float&,float&);
	void guize();
	int r,dn;
};

